import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';
import 'package:qr_code_scanner/qr_code_scanner.dart';
import 'package:qrcode_in_webview/screens/webview_dois.dart';
import 'package:qrcode_in_webview/utils/colors.dart';
import 'package:url_launcher/url_launcher.dart' as url_launcher;

class WelcomeScreen extends StatefulWidget {
  late String title;

  WelcomeScreen(this.title);

  @override
  _WelcomeScreenState createState() => _WelcomeScreenState();
}

class _WelcomeScreenState extends State<WelcomeScreen> {
  final GlobalKey qrKey = GlobalKey(debugLabel: 'QR');
  QRViewController? controller;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ColorUtils.azul_escuro,
      body: Container(
        alignment: Alignment.topCenter,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: <Widget>[
            SizedBox(height: 30),
            Text(
              "Olá, seja bem vindo!",
              textAlign: TextAlign.center,
              style: TextStyle(color: ColorUtils.branco_texto, fontSize: 28.0),
            ),
            SizedBox(height: 100),
            Image.asset(
              'assets/logo.png',
              width: 200.0,
              height: 200.0,
            ),
            SizedBox(height: 100),
            QRView(
              key: qrKey,
              onQRViewCreated: _onQRViewCreated,
            ),
            RaisedButton(
              textColor: ColorUtils.azul_escuro,
              color: ColorUtils.branco_texto,
              child: Text(
                "Iniciar inspeção",
                textAlign: TextAlign.center,
                style: TextStyle(color: ColorUtils.azul_escuro, fontSize: 22.0),
              ),
              onPressed: () {
                _scanQR(context);
              },
              shape: new RoundedRectangleBorder(
                borderRadius: new BorderRadius.circular(30.0),
              ),
            ),
            Container(
              margin: EdgeInsets.only(bottom: 5.0, right: 20.0),
              alignment: Alignment.topRight,
              child: Image.asset(
                'assets/logo_branco.png',
                height: 30,
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _onQRViewCreated(QRViewController controller) {
    this.controller = controller;
    controller.scannedDataStream.listen((scanData) {
      setState(() {
        _openInWebview(context, scanData.code);
      });
    }).onError((error) {
      setState(() {
        _showDialog("Erro desconhecido. $error");
      });
    });
  }

  @override
  void dispose() {
    controller?.dispose();
    super.dispose();
  }

  Future _scanQR(BuildContext context) async {
    try {
      // String qrResult = await BarcodeScanner.scan();
      //
      // setState(() {
      //   _openInWebview(context, qrResult);
      // });
    } on PlatformException catch (ex) {
      setState(() {
        _showDialog("Erro desconhecido. $ex");
      });
    } on FormatException {} catch (ex) {
      setState(() {
        _showDialog("Erro desconhecido. $ex");
      });
    }
  }

  Future<Null> _openInWebview(BuildContext context, String url) async {
    if (await url_launcher.canLaunch(url)) {
      // Navigator.push(
      //     context, MaterialPageRoute(builder: (context) => WebviewState(url)));
      Navigator.push(
          context, MaterialPageRoute(builder: (context) => MyWebviewDois(url)));
    } else {
      _showDialog("A url $url não pode ser aberta");
    }
  }

  void _showDialog(String mensagem) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: new Text("Opsss..."),
          content: new Text(mensagem),
          actions: <Widget>[
            new TextButton(
              child: new Text("Fechar"),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }
}
