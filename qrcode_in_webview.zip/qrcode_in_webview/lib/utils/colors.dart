import 'package:flutter/cupertino.dart';

class ColorUtils {
  static Color azul_escuro = Color(0xff141b2d);
  static Color branco_texto = Color(0xfffefdfd);
}
