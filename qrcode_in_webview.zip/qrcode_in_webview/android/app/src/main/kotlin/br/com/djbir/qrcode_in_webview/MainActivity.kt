package br.com.djbir.qrcode_in_webview

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
